package domparseFE019W;

import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class DOMModifyFE019W {
	
	public static void main(String args[]) throws SAXException, IOException, ParserConfigurationException {

		//l�trehozunk egy dokumentum olvas�t
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		
		try {
			//l�trehozunk egy �j DOM objektumot a megl�v� XML f�jlb�l
			DocumentBuilder builder = factory.newDocumentBuilder();
			Document doc = builder.parse(
					"C:\\Users\\farka\\eclipse-workspace\\XML\\DOMParseFE019W\\src\\domparseFE019W\\XMLFE019W.xml");
			
			//normaliz�ljuk a dokumentumot
			doc.getDocumentElement().normalize();

			//A megadott xml dokumentum Bolognese nev� pizz�inak m�ret�t 30-ra m�dos�tjuk
			update(doc, "Bolognese", 30);
			
		} catch (Exception ee) {
			ee.printStackTrace();
		}
	}
	
	//Adatm�dos�t�s: a megadott fajt�j� pizza m�ret�nek megv�ltoztat�sa a megadott m�retre
	public static void update (Document dom, String fajta, int ujmeret) {
		int p, q, r, kell = 0;
		int emeret = 0;
		String efajta = null;
		Node elem = null;
		
		//root node lek�rdez�se
		Node root = dom.getDocumentElement();
		
		//v�gigiter�lunk a root node child node-jain �s megkeress�k a megadott fajta node-j�t
		//majd megkeress�k a megadott node-ban a megadott fajta node-j�nak sz�veg tartalm�t
		for(p=0; p<root.getChildNodes().getLength(); p++) {
			elem = root.getChildNodes().item(p);
			if (elem.getNodeName().compareTo("pizza") == 0) {
				kell = 0;
				for (q=0; q<elem.getChildNodes().getLength(); q++) {
					Node ujelem = elem.getChildNodes().item(q);
					if (ujelem.getNodeType() == Node.ELEMENT_NODE) {
						if (ujelem.getNodeName().compareTo("fajta") == 0) {
							for (r=0; r<ujelem.getChildNodes().getLength(); r++) {
								Node ujabbelem = ujelem.getChildNodes().item(r);
								if (ujabbelem.getNodeType() == Node.TEXT_NODE) {
									efajta = ujabbelem.getTextContent();
									if (efajta.compareTo(fajta) == 0) {
										kell = 1;
									}
								}
							}
						}
					}
				}
			}
			//ha megvan a megadott fajta, akkor a megadott fajta m�ret node-j�nak sz�veg tartalm�t kicser�lj�k a
			//megadott m�retre
			if (kell == 1) {
				for (q=0; q<elem.getChildNodes().getLength(); q++) {
					Node ujelem = elem.getChildNodes().item(q);
					if (ujelem.getNodeType() == Node.ELEMENT_NODE) {
						if (ujelem.getNodeName().compareTo("meret") == 0) {
							for (r=0; r<ujelem.getChildNodes().getLength(); r++) {
								Node ujabbelem = ujelem.getChildNodes().item(r);
								if (ujabbelem.getNodeType() == Node.TEXT_NODE) {
									emeret = Integer.parseInt(ujabbelem.getTextContent());
									System.out.println("Eredeti meret: " + emeret);
									String ujszov = String.valueOf(ujmeret);
									ujabbelem.setNodeValue(ujszov);
									System.out.println("Uj meret: " + ujmeret);
								}
							}
						}
					}
				}	
			}
		}
	}
}

package domparseFE019W;

import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class DOMReadFE019W {

	public static void main(String args[]) throws SAXException, IOException, ParserConfigurationException {

		//l�trehozunk egy dokumentum olvas�t
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		
		try {
			//l�trehozunk egy �j DOM objektumot a megl�v� XML f�jlb�l
			DocumentBuilder builder = factory.newDocumentBuilder();
			Document doc = builder.parse(
					"C:\\Users\\farka\\eclipse-workspace\\XML\\DOMParseFE019W\\src\\domparseFE019W\\XMLFE019W.xml");
			
			//normaliz�ljuk a dokumentumot
			doc.getDocumentElement().normalize();

			System.out.println("The data of the XML document read:");

			//root elem ki�rat�sa �s elem kiv�laszt�s tag n�v alapj�n
			System.out.println("Root element : " + doc.getDocumentElement().getNodeName());
			
			//a megadott nev� elemekb�l k�sz�t�nk egy list�t, majd v�gigiter�lunk a list�n, az
			//egyes elemekb�l kiolvassuk a sz�veg node-ot, �s a tartalmat ki�ratjuk a k�perny�re
			NodeList nList = doc.getElementsByTagName("megrendelo");
			for (int temp = 0; temp < nList.getLength(); temp++) {
				Node nNode = nList.item(temp);
				System.out.println("\nCurrent Element : " + nNode.getNodeName());

				if (nNode.getNodeType() == Node.ELEMENT_NODE) {
					Element eElement = (Element) nNode;
					System.out.println("Megrendelo id-je : " + eElement.getAttribute("mkod"));
					System.out.println(
							"Megrendelo neve : " + eElement.getElementsByTagName("nev").item(0).getTextContent());
					System.out.println("Megrendelo telefonszama : "
							+ eElement.getElementsByTagName("telefonszam").item(0).getTextContent());
					System.out.println(
							"Megrendelo lakcime : " + eElement.getElementsByTagName("lakcim").item(0).getTextContent());
				}
			}

			nList = doc.getElementsByTagName("futar");
			for (int temp = 0; temp < nList.getLength(); temp++) {
				Node nNode = nList.item(temp);
				System.out.println("\nCurrent Element : " + nNode.getNodeName());

				if (nNode.getNodeType() == Node.ELEMENT_NODE) {
					Element eElement = (Element) nNode;
					System.out.println("Futar id-je : " + eElement.getAttribute("fkod"));
					System.out.println("Futar telefonszama : "
							+ eElement.getElementsByTagName("telefonszam").item(0).getTextContent());
					System.out.println("Futar neve : " + eElement.getElementsByTagName("nev").item(0).getTextContent());
					System.out.println(
							"Futar eletkora : " + eElement.getElementsByTagName("eletkor").item(0).getTextContent());
					System.out.println("Futar robogo tipusa : "
							+ eElement.getElementsByTagName("robogoTipus").item(0).getTextContent());
				}
			}

			nList = doc.getElementsByTagName("pizza");
			for (int temp = 0; temp < nList.getLength(); temp++) {
				Node nNode = nList.item(temp);
				System.out.println("\nCurrent Element : " + nNode.getNodeName());

				if (nNode.getNodeType() == Node.ELEMENT_NODE) {
					Element eElement = (Element) nNode;
					System.out.println("Pizza id-je : " + eElement.getAttribute("pkod"));
					System.out.println(
							"Pizza fajtaja : " + eElement.getElementsByTagName("fajta").item(0).getTextContent());
					System.out.println(
							"Pizza merete : " + eElement.getElementsByTagName("meret").item(0).getTextContent());
					System.out.println("Pizza ara : " + eElement.getElementsByTagName("ar").item(0).getTextContent());
				}
			}

			nList = doc.getElementsByTagName("szakacs");
			for (int temp = 0; temp < nList.getLength(); temp++) {
				Node nNode = nList.item(temp);
				System.out.println("\nCurrent Element : " + nNode.getNodeName());

				if (nNode.getNodeType() == Node.ELEMENT_NODE) {
					Element eElement = (Element) nNode;
					System.out.println("Szakacs id-je : " + eElement.getAttribute("szkod"));
					System.out
							.println("Szakacs neve : " + eElement.getElementsByTagName("nev").item(0).getTextContent());
					System.out.println(
							"Szakacs eletkora : " + eElement.getElementsByTagName("eletkor").item(0).getTextContent());
					System.out.println("Szakacs kepesitese : "
							+ eElement.getElementsByTagName("kepesites").item(0).getTextContent());
				}
			}

			nList = doc.getElementsByTagName("belepokartya");
			for (int temp = 0; temp < nList.getLength(); temp++) {
				Node nNode = nList.item(temp);
				System.out.println("\nCurrent Element : " + nNode.getNodeName());

				if (nNode.getNodeType() == Node.ELEMENT_NODE) {
					Element eElement = (Element) nNode;
					System.out.println("Belepokartya id-je : " + eElement.getAttribute("bkod"));
					System.out.println("Belepokartya azonositoja : "
							+ eElement.getElementsByTagName("azonosito").item(0).getTextContent());
					System.out.println("Belepokartya kiadasanak eve : "
							+ eElement.getElementsByTagName("kiadasEve").item(0).getTextContent());
					System.out.println("Belepokartya lejaratanak eve : "
							+ eElement.getElementsByTagName("lejaratEve").item(0).getTextContent());
				}
			}

			nList = doc.getElementsByTagName("osszetevo");
			for (int temp = 0; temp < nList.getLength(); temp++) {
				Node nNode = nList.item(temp);
				System.out.println("\nCurrent Element : " + nNode.getNodeName());

				if (nNode.getNodeType() == Node.ELEMENT_NODE) {
					Element eElement = (Element) nNode;
					System.out.println("Osszetevo id-je : " + eElement.getAttribute("okod"));
					System.out.println("Osszetevo neve : "
							+ eElement.getElementsByTagName("nev").item(0).getTextContent());
					System.out.println("Osszetevo tipusa : "
							+ eElement.getElementsByTagName("tipus").item(0).getTextContent());
					System.out.println("Osszetevo tomege : "
							+ eElement.getElementsByTagName("tomeg").item(0).getTextContent());
					System.out.println("Osszetevo lajarata : "
							+ eElement.getElementsByTagName("lejarat").item(0).getTextContent());
				}
			}
			
			nList = doc.getElementsByTagName("szukseges");
			for (int temp = 0; temp < nList.getLength(); temp++) {
				Node nNode = nList.item(temp);
				System.out.println("\nCurrent Element : " + nNode.getNodeName());

				if (nNode.getNodeType() == Node.ELEMENT_NODE) {
					Element eElement = (Element) nNode;
					System.out.println("Szukseges pizza id-je : " + eElement.getAttribute("pkod"));
					System.out.println("Szukseges osszetevo id-je : " + eElement.getAttribute("okod"));
				}
			}

		} catch (Exception ee) {
			ee.printStackTrace();
		}
	}
}
